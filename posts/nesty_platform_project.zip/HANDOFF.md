# Nesty — Platform film 02 · build notes

1080×1920 · 30fps · H.264 · **61.30s** · AAC 256k. Your voiceover, with an ambient bed under it.

## Sync

Your read has 22 spoken passages with pauses inside sentences, so I solved the nine shot
boundaries as a constrained optimisation rather than guessing: each shot's share of the film is
matched to its line's syllable weight, boundaries are pulled toward the longest pauses, and every
shot is held between 3.6s and 10.5s. Result:

| cut | clearance from nearest word |
|---|---|
| 7.07 | 0.90s |
| 13.00 | 0.67s |
| 20.73 | 0.82s |
| 27.13 | 0.51s |
| 34.97 | 0.92s |
| 41.43 | 0.44s |
| 45.60 | in the 46.41 pause |
| 53.57 | 0.87s |

No cut lands on a word. The bed fades out at 58.55 so your closing line plays in silence, and
the film holds 1.5s of black-and-silence after the last word.

**If a caption sits on the wrong sentence**, tell me the shot number and I'll shift one boundary —
it's a single re-render, not a rebuild.

## What's on screen

Frames are desktop browser windows, as you asked — the site, the agency workspace and Base all
sit in a window with the real URL in the address bar. The app is the one phone in the film,
because it is the one surface that is actually mobile.

Labels are the real ones, captured from your logged-in session: `Aperçu · Annonces · Calendrier ·
Réservations · Incidents · Assistance · Paramètres`, the `Confirmée / En attente / Bloquée`
legend, `Dashboard · Verifications · Agencies · Users · Tickets · Incidents · Analytics ·
Activity` in Base, and `VÉRIFIÉ` / `Visite 3D` on the listing.

Nothing on screen is a real record: no names, no emails, no registration numbers, and **no
counts anywhere** — the workspace tiles carry labels and bars instead of digits, because your
brand kit bars any number of agencies, users, listings or bookings until they are real.

## Motion

- Every interface **builds** rather than sitting still: frame, then sidebar, then tiles, then rows, each on a 60–70ms stagger.
- Shot 5 changes view inside the shot — Aperçu to Calendrier, with the sidebar's active state moving with it.
- Shot 6 flips four verification rows from `En attente` to `Vérifié`, one after another.
- Shot 4 runs a 3D scan over the listing photo, in ink so it reads on a light image.
- Shot 7 sends a booking down the wire from the app to the agency space, with a ring pulse on arrival.
- Push-in is scaled by shot length, so the move is the same speed per second in a 4s shot and an 8s one.

Max chroma deviation across all 1,839 frames: **0**.

## Still open in the product

`demandes avec SLA` / `requests with SLAs` is still live on the landing in both locales. Third
time flagged. The three named testimonials are still there too, and stay out of the film.
